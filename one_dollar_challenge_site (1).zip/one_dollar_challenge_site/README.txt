ONE DOLLAR CHALLENGE — WEBSITE FILES

Contents:
- index.html: responsive single-page website
- assets/logo.png: campaign logo crop

Preview:
Open index.html in a modern browser.

Publishing:
This folder must be uploaded to a static website host (for example, GitHub Pages or Netlify) to become publicly accessible. This package does not publish the site automatically.

Before accepting any donations:
1. Decide and disclose the exact use of funds.
2. Disclose who controls the funds, fees, expenses, organizer compensation, and treatment of unused funds.
3. Verify a payment provider that legally supports receiving and withdrawing funds in your country.
4. Add the payment link only after the disclosures and provider checks are complete.

The site intentionally has no payment button and clearly says donations are not being accepted yet.
